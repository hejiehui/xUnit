using System;
using System.Collections.Generic;

namespace com.xross.tools.xunit.def
{
    public class UnitDefRepo
    {
        private IDictionary<String, String> applicationProperties;
        private IDictionary<String, UnitDef> defRepo = new Dictionary<String, UnitDef>();

        public UnitDefRepo(IDictionary<String, String> applicationProperties)
        {
            this.applicationProperties = applicationProperties;
        }

        public IDictionary<String, String> getApplicationProperties()
        {
            return applicationProperties;
        }

        public void put(String key, UnitDef unitDef)
        {
            if (!defRepo.ContainsKey(key))
                defRepo.Add(key, null);
            defRepo[key] = unitDef;
        }

        public UnitDef getDef(String id)
        {
            if (!defRepo.ContainsKey(id))
                return null;
            return defRepo[id];
        }

        public Unit getUnit(String id)
        {
            try
            {
                if (!defRepo.ContainsKey(id))
                    return null;
                return defRepo[id].getInstance();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}