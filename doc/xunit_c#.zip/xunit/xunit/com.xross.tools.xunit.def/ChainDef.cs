using com.xross.tools.xunit.impl;
using System;
using System.Collections.Generic;

namespace com.xross.tools.xunit.def
{
    public class ChainDef : UnitDef
    {
        private IList<UnitDef> unitDefs = new List<UnitDef>();

        public IList<UnitDef> getUnitDefs()
        {
            return unitDefs;
        }

        public void addUnitDef(UnitDef unitDef)
        {
            unitDefs.Add(unitDef);
        }

        protected override Unit createDefault()
        {
            return new ChainImpl();
        }

        protected override Unit createInstance()
        {
            try
            {
                Chain chain = (Chain)base.createInstance();

                foreach (UnitDef def in unitDefs)
                    chain.add(getInstance(def));

                return chain;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}