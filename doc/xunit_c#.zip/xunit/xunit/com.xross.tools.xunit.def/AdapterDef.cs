using System;

namespace com.xross.tools.xunit.def
{
    public class AdapterDef : UnitDef
    {
        private UnitDef unitDef;

        public UnitDef getUnitDef()
        {
            return unitDef;
        }

        public void setUnitDef(UnitDef unitDef)
        {
            this.unitDef = unitDef;
        }

        protected override Unit createInstance()
        {
            try
            {
                Adapter adapter = (Adapter)base.createInstance();
                adapter.setUnit(getInstance(unitDef));
                return adapter;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}