using System;

namespace com.xross.tools.xunit.def
{
    public class DecoratorDef : UnitDef
    {
        private UnitDef unitDef;

        public UnitDef getUnitDef()
        {
            return unitDef;
        }

        public void setUnitDef(UnitDef unitDef)
        {
            this.unitDef = unitDef;
        }

        protected override Unit createInstance()
        {
            try
            {
                Decorator decorator = (Decorator)base.createInstance();
                decorator.setUnit(getInstance(unitDef));
                return decorator;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}