using com.xross.tools.xunit.impl;
using System;
using System.Collections.Generic;
using System.Linq;

namespace com.xross.tools.xunit.def
{
    public class UnitDef
    {
        protected UnitDefRepo repo;
        private String name;
        private Behavior.BehaviorType type;
        private String description;
        private Boolean singleton;
        private Unit instance;
        private String className;
        private String referenceName;
        private String key;
        private Dictionary<String, String> properties;

        public void setUnitDefRepo(UnitDefRepo repo)
        {
            this.repo = repo;
        }

        public Behavior.BehaviorType getType()
        {
            return type;
        }

        public void setType(Behavior.BehaviorType type)
        {
            this.type = type;
        }

        public String getKey()
        {
            return key;
        }

        public void setKey(String key)
        {
            this.key = key;
        }

        public String getName()
        {
            return name;
        }

        public void setName(String name)
        {
            this.name = name;
        }

        public String getDescription()
        {
            return description;
        }

        public void setDescription(String description)
        {
            this.description = description;
        }

        public Boolean isSingleton()
        {
            return singleton;
        }

        public void setSingleton(Boolean singleton)
        {
            this.singleton = singleton;
        }

        public String getClassName()
        {
            return className;
        }

        public void setClassName(String className)
        {
            this.className = className;
        }

        public String getReferenceName()
        {
            return referenceName;
        }

        public void setReferenceName(String referenceName)
        {
            this.referenceName = referenceName;
        }

        public void setProperties(Dictionary<String, String> properties)
        {
            this.properties = properties;
        }

        private Boolean isEmpty(String str)
        {
            if (str == null || str.Trim().Length == 0)
                return true;
            return str.Trim().Equals("default", StringComparison.OrdinalIgnoreCase);
        }

        protected virtual Unit createDefault()
        {
            return new DefaultUnitImpl(this);
        }

        protected virtual Unit createInstance()
        {
            try
            {
                if (!isEmpty(className))
                {
                    Type type = null;
                    types.TryGetValue(className.ToLower(), out type);
                    Unit unit = (Unit)Activator.CreateInstance(type);    //(Unit)Class.forName(className).newInstance();

                    if (unit is ApplicationPropertiesAware)
                    {
                        ApplicationPropertiesAware aware = (ApplicationPropertiesAware)unit;
                        // Make a copy
                        aware.setApplicationProperties(new Dictionary<String, String>(repo.getApplicationProperties()));
                    }

                    if (unit is UnitPropertiesAware)
                    {
                        UnitPropertiesAware aware = (UnitPropertiesAware)unit;
                        // Make a copy
                        aware.setUnitProperties(new Dictionary<String, String>(properties));
                    }
                    return unit;
                }

                if (!isEmpty(referenceName))
                    return repo.getUnit(referenceName);
                return createDefault();
            }
            catch (Exception)
            {
                throw;
            }
        }

        private IDictionary<String, Type> _types = null;

        private IDictionary<String, Type> types
        {
            get
            {
                if (_types == null)
                {
                    _types = new Dictionary<String, Type>();
                    var assemblies = AppDomain.CurrentDomain.GetAssemblies().Where(p => !p.GlobalAssemblyCache);

                    if (assemblies == null)
                        return _types;

                    foreach (var assembly in assemblies)
                    {
                        Type[] definedTypes = assembly.GetTypes();
                        if (definedTypes == null || definedTypes.Length == 0)
                            continue;

                        foreach (var type in definedTypes)
                        {
                            String typeName = type.FullName.ToLower();
                            if (!_types.ContainsKey(typeName))
                                _types.Add(typeName, type);
                        }
                    }
                }

                return _types;
            }
        }

        /**
         * if it is singleton, we should return the only instance
         * @return
         * @throws Exception 
         */
        public Unit getInstance()
        {
            try
            {
                if (singleton)
                    if (instance != null)
                        return instance;
                    else
                        return instance = createInstance();

                return createInstance();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /**
         * Just a helper method to let subclass create child unit.
         * The parent  
         */
        public static Unit getInstance(UnitDef def)
        {
            try
            {
                return def == null ? null : def.getInstance();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}