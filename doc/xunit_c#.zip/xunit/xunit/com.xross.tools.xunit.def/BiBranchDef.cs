using com.xross.tools.xunit.impl;
using System;

namespace com.xross.tools.xunit.def
{
    public class BiBranchDef : UnitDef
    {
        private ValidatorDef validatorDef;
        private UnitDef validUnitDef;
        private UnitDef invalidUnitDef;

        public ValidatorDef getValidatorDef()
        {
            return validatorDef;
        }

        public void setValidatorDef(ValidatorDef validatorDef)
        {
            this.validatorDef = validatorDef;
        }

        public UnitDef getValidUnitDef()
        {
            return validUnitDef;
        }

        public void setValidUnitDef(UnitDef validUnitDef)
        {
            this.validUnitDef = validUnitDef;
        }

        public UnitDef getInvalidUnitDef()
        {
            return invalidUnitDef;
        }

        public void setInvalidUnitDef(UnitDef invalidUnitDef)
        {
            this.invalidUnitDef = invalidUnitDef;
        }

        protected override Unit createDefault()
        {
            return new BiBranchImpl();
        }

        protected override Unit createInstance()
        {
            try
            {
                BiBranch biBranch = (BiBranch)base.createInstance();

                biBranch.setValidator((Validator)getInstance(validatorDef));
                biBranch.setValidUnit(getInstance(validUnitDef));
                biBranch.setInvalidUnit(getInstance(invalidUnitDef));

                return biBranch;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}