using com.xross.tools.xunit.impl;
using System.Collections.Generic;

namespace com.xross.tools.xunit.def
{
    public class BranchDef : UnitDef
    {
        private UnitDef locatorDef;
        private IList<UnitDef> branchUnitDefs = new List<UnitDef>();

        public UnitDef getLocatorDef()
        {
            return locatorDef;
        }

        public void setLocatorDef(UnitDef locatorDef)
        {
            this.locatorDef = locatorDef;
        }

        public IList<UnitDef> getBranchUnitDefs()
        {
            return branchUnitDefs;
        }

        public void addBranchUnitDef(UnitDef branchUnitDef)
        {
            branchUnitDefs.Add(branchUnitDef);
        }

        protected override Unit createDefault()
        {
            return new BranchImpl();
        }

        protected override Unit createInstance()
        {
            try
            {
                Branch branch = (Branch)base.createInstance();
                branch.setLocator((Locator)getInstance(locatorDef));

                foreach (UnitDef def in branchUnitDefs)
                {
                    Unit unit = getInstance(def);
                    branch.add(def.getKey(), unit);
                }

                return branch;
            }
            catch (System.Exception)
            {
                throw;
            }
        }
    }
}