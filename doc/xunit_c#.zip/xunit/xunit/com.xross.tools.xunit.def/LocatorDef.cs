using System;

namespace com.xross.tools.xunit.def
{
    public class LocatorDef : UnitDef
    {
        private String defaultKey;

        public String getDefaultKey()
        {
            return defaultKey;
        }

        public void setDefaultKey(String defaultKey)
        {
            this.defaultKey = defaultKey;
        }

        protected override Unit createInstance()
        {
            try
            {
                Locator locator = (Locator)base.createInstance();

                locator.setDefaultKey(defaultKey);

                return locator;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}