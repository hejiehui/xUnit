using com.xross.tools.xunit.impl;
using System;

namespace com.xross.tools.xunit.def
{
    public class LoopDef : UnitDef
    {
        private Boolean whileLoop;
        private ValidatorDef validatorDef;
        private UnitDef unitDef;

        public LoopDef(Boolean whileLoop)
        {
            this.whileLoop = whileLoop;
        }

        public ValidatorDef getValidatorDef()
        {
            return validatorDef;
        }

        public void setValidatorDef(ValidatorDef validatorDef)
        {
            this.validatorDef = validatorDef;
        }

        public UnitDef getUnitDef()
        {
            return unitDef;
        }

        public void setUnitDef(UnitDef unitDef)
        {
            this.unitDef = unitDef;
        }

        protected override Unit createDefault()
        {
            return whileLoop ?
                    new PreValidationLoopImpl() as Unit :
                        new PostValidationLoopImpl();
        }

        protected override Unit createInstance()
        {
            try
            {
                BaseValidationLoop loop = (BaseValidationLoop)base.createInstance();

                loop.setValidator((Validator)getInstance(validatorDef));
                loop.setUnit(getInstance(unitDef));

                return (Processor)loop;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}