namespace com.xross.tools.xunit.impl
{
    public abstract class BaseValidationLoopImpl : BaseCompositeImpl, BaseValidationLoop
    {
        protected Validator validator;
        protected Unit unit;

        public void setValidator(Validator validator)
        {
            this.validator = validator;
        }

        public void setUnit(Unit unit)
        {
            this.unit = unit;
        }
    }
}