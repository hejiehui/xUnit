namespace com.xross.tools.xunit.impl
{
    public abstract class BaseCompositeImpl : Processor, Converter
    {
        public abstract void process(Context ctx);

        public abstract Context convert(Context inputCtx);

        protected void process(Unit unit, Context ctx)
        {
            if (unit == null)
                return;

            if (unit is Processor)
            {
                ((Processor)unit).process(ctx);
                return;
            }

            // For converter, we simply ignore the output
            if (unit is Converter)
                ((Converter)unit).convert(ctx);
        }

        protected Context convert(Unit unit, Context inputCtx)
        {
            if (unit == null)
                return inputCtx;

            if (unit is Converter)
                return ((Converter)unit).convert(inputCtx);

            // For processor, we simply return the input
            if (unit is Processor)
                ((Processor)unit).process(inputCtx);

            return inputCtx;
        }
    }
}