namespace com.xross.tools.xunit.impl
{
    public class PreValidationLoopImpl : BaseValidationLoopImpl
    {
        public override void process(Context ctx)
        {
            while (validator.validate(ctx))
                process(unit, ctx);
        }

        public override Context convert(Context inputCtx)
        {
            while (validator.validate(inputCtx))
                inputCtx = convert(unit, inputCtx);
            return inputCtx;
        }
    }
}