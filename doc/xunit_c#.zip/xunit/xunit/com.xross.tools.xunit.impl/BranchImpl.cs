using System;
using System.Collections.Generic;

namespace com.xross.tools.xunit.impl
{
    public class BranchImpl : BaseCompositeImpl, Branch
    {
        private Locator locator;
        private IDictionary<String, Unit> unitMap = new Dictionary<String, Unit>();

        public void setLocator(Locator locator)
        {
            this.locator = locator;
        }

        public void add(String key, Unit unit)
        {
            if (!unitMap.ContainsKey(key))
                unitMap.Add(key, null);

            unitMap[key] = unit;
        }

        protected Unit locateUnit(Context ctx)
        {
            String key = locator.locate(ctx);
            Unit unit = null;
            unitMap.TryGetValue(key, out unit);
            if (unit != null)
                return unit;

            unitMap.TryGetValue(locator.getDefaultKey(), out unit);
            return unit;
        }

        public override void process(Context ctx)
        {
            process(locateUnit(ctx), ctx);
        }

        public override Context convert(Context inputCtx)
        {
            return convert(locateUnit(inputCtx), inputCtx);
        }
    }
}