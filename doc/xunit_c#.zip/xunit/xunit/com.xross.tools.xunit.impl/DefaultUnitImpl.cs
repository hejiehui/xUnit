using com.xross.tools.xunit.def;
using System;

namespace com.xross.tools.xunit.impl
{
    /**
     * This unit implementation is just for quick verifying system.
     * @author jiehe
     *
     */
    public class DefaultUnitImpl : Processor, Converter, Validator, Locator, Decorator, Adapter
    {
        private UnitDef unitDef;

        private String key;

        public DefaultUnitImpl(UnitDef unitDef)
        {
            this.unitDef = unitDef;
        }

        public void setDefaultKey(String key)
        {
            this.key = key;
        }

        public String getDefaultKey()
        {
            return key;
        }

        public String locate(Context ctx)
        {
            return key;
        }

        public Boolean validate(Context ctx)
        {
            return true;
        }

        public Context convert(Context inputCtx)
        {
            return inputCtx;
        }

        public void process(Context ctx) { }

        public void setUnit(Unit unit) { }

        public void before(Context ctx) { }

        public void after(Context ctx) { }
    }
}