namespace com.xross.tools.xunit.impl
{
    public class PostValidationLoopImpl : BaseValidationLoopImpl
    {
        public override void process(Context ctx)
        {
            do
            {
                process(unit, ctx);
            } while (validator.validate(ctx));
        }

        public override Context convert(Context inputCtx)
        {
            do
            {
                inputCtx = convert(unit, inputCtx);
            } while (validator.validate(inputCtx));
            return inputCtx;
        }
    }
}