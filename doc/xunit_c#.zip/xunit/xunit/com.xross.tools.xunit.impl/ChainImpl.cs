using System.Collections.Generic;

namespace com.xross.tools.xunit.impl
{
    public class ChainImpl : BaseCompositeImpl, Chain
    {
        private IList<Unit> units = new List<Unit>();

        public void add(Unit unit)
        {
            units.Add(unit);
        }

        public override void process(Context ctx)
        {
            foreach (Unit unit in units)
                process(unit, ctx);
        }

        public override Context convert(Context inputCtx)
        {
            foreach (Unit unit in units)
                inputCtx = convert(unit, inputCtx);

            return inputCtx;
        }
    }
}