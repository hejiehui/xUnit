namespace com.xross.tools.xunit.impl
{
    public class BiBranchImpl : BaseCompositeImpl, BiBranch
    {
        private Validator validator;
        private Unit validUnit;
        private Unit invalidUnit;

        public void setValidator(Validator validator)
        {
            this.validator = validator;
        }

        public void setValidUnit(Unit unit)
        {
            this.validUnit = unit;
        }

        public void setInvalidUnit(Unit unit)
        {
            this.invalidUnit = unit;
        }

        public override void process(Context ctx)
        {
            if (validator.validate(ctx))
                process(validUnit, ctx);
            else
                process(invalidUnit, ctx);
        }

        public override Context convert(Context ctx)
        {
            if (validator.validate(ctx))
                return convert(validUnit, ctx);
            else
                return convert(invalidUnit, ctx);
        }
    }
}