using System;

namespace com.xross.tools.xunit.impl
{
    public abstract class DecoratorAdapter : Decorator, Processor, Converter, Validator, Locator
    {
        public abstract void before(Context ctx);

        public abstract void after(Context ctx);

        private Unit unit;

        public void setUnit(Unit unit)
        {
            this.unit = unit;
        }

        public void setDefaultKey(String key)
        {
            ((Locator)unit).setDefaultKey(key);
        }

        public String getDefaultKey()
        {
            return ((Locator)unit).getDefaultKey();
        }

        public String locate(Context ctx)
        {
            before(ctx);
            String key = ((Locator)unit).locate(ctx);
            after(ctx);
            return key;
        }

        public Boolean validate(Context ctx)
        {
            before(ctx);
            Boolean result = ((Validator)unit).validate(ctx);
            after(ctx);
            return result;
        }

        public Context convert(Context inputCtx)
        {
            before(inputCtx);
            Context output = ((Converter)unit).convert(inputCtx);
            after(inputCtx);
            return output;
        }

        public void process(Context ctx)
        {
            before(ctx);
            ((Processor)unit).process(ctx);
            after(ctx);
        }
    }
}