namespace com.xross.tools.xunit
{
    public interface BaseValidationLoop : Unit
    {
        void setValidator(Validator validator);
        void setUnit(Unit unit);
    }
}