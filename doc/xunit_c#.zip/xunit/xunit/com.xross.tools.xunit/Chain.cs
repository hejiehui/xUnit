namespace com.xross.tools.xunit
{
    public interface Chain : Unit
    {
        void add(Unit unit);
    }
}