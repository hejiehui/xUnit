namespace com.xross.tools.xunit
{
    public interface Context { }
}