using System;
using System.Collections.Generic;

namespace com.xross.tools.xunit
{
    // TODO move to common
    public interface UnitPropertiesAware
    {
        void setUnitProperties(IDictionary<String, String> properties);
    }
}