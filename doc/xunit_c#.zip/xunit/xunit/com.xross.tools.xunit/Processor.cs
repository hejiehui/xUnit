namespace com.xross.tools.xunit
{
    public interface Processor : Unit
    {
        void process(Context ctx);
    }
}