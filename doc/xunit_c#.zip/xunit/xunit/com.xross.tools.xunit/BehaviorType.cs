using System;

namespace com.xross.tools.xunit
{
    public class Behavior
    {
        public enum BehaviorType { processor, converter, validator, locator }

        public static String[] names = getNames();

        private static String[] getNames()
        {
            String[] names = new String[] { BehaviorType.processor.ToString(), BehaviorType.converter.ToString() };
            return names;
        }

        public static BehaviorType getType(int index)
        {
            Array array = Enum.GetValues(typeof(BehaviorType));
            return (BehaviorType)array.GetValue(index);
        }
    }
}