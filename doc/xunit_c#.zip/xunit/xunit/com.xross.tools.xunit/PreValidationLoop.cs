namespace com.xross.tools.xunit
{
    public interface PreValidationLoop : BaseValidationLoop { }
}