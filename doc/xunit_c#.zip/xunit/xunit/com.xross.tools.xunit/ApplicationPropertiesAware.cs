using System;
using System.Collections.Generic;

namespace com.xross.tools.xunit
{
    public interface ApplicationPropertiesAware
    {
        void setApplicationProperties(IDictionary<String, String> properties);
    }
}