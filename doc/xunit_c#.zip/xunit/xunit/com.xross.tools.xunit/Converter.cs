namespace com.xross.tools.xunit
{
    public interface Converter : Unit
    {
        Context convert(Context inputCtx);
    }
}