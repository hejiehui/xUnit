using System;
using System.Collections.Generic;

namespace com.xross.tools.xunit
{
    [Obsolete]
    public class UnitConfigure : XunitConstants
    {
        private IDictionary<String, IDictionary<String, String>> categories = new Dictionary<String, IDictionary<String, String>>();

        void setVale(String key, String value)
        {
            setVale(DEFAULT_CATEGORY, key, value);
        }

        void setVale(String category, String key, String value)
        {
            if (!categories.ContainsKey(category))
                categories.Add(category, new Dictionary<String, String>());

            if (!categories[category].ContainsKey(key))
                categories[category].Add(key, null);

            categories[category][key] = value;
        }

        public String getValue(String key)
        {
            return getValue(DEFAULT_CATEGORY, key);
        }

        public String getValue(String category, String key)
        {
            if (!categories.ContainsKey(category))
                return null;

            if (!categories[category].ContainsKey(key))
                return null;

            return categories[category][key];
        }
    }
}