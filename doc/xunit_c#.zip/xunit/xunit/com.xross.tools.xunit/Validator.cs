using System;

namespace com.xross.tools.xunit
{
    public interface Validator : Unit
    {
        Boolean validate(Context ctx);
    }
}