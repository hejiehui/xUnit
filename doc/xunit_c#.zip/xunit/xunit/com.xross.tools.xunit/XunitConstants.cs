using System;

namespace com.xross.tools.xunit
{
    public class XunitConstants
    {
        protected String XUNIT = "xunit";
        protected static String PACKAGE_ID = "packageId";
        protected String PROPERTIES = "properties";
        protected String CATEGORY = "category";
        protected String DEFAULT_CATEGORY = "default";
        protected String ENTRY = "entry";
        protected String PROPERTY = "property";
        protected String VALUE = "value";
        protected static String NAME = "name";
        protected String CLASS = "class";
        protected String REFERENCE = "reference";
        protected String DESCRIPTION = "description";
        protected String IMPORTS = "imports";
        protected String IMPORT = "import";
        protected String UNITS = "units";
        protected String UNIT = "unit";
        protected String TYPE = "type";
        protected String STRUCTURE_TYPE = "structure_type";
        protected String PROCESSOR = "processor";
        protected String CONVERTER = "converter";
        protected String DECORATOR = "decorator";
        protected static String DECORATOR_UNIT = "decorator_unit";
        protected String ADAPTER = "adapter";
        protected static String ADAPTER_UNIT = "adapter_unit";
        protected String LOCATOR = "locator";
        protected String DEFAULT_KEY = "default_key";
        protected String VALIDATOR = "validator";
        protected String VALID_LABEL = "validLabel";
        protected String INVALID_LABEL = "invalidLabel";
        protected String CHAIN = "chain";
        protected String BI_BRANCH = "bi_branch";
        protected static String VALID_UNIT = "valid_unit";
        protected static String INVALID_UNIT = "invalid_unit";
        protected String BRANCH = "branch";
        protected static String BRANCH_UNIT = "branch_unit";
        protected String KEY = "key";
        protected String WHILE = "while";
        protected String DO_WHILE = "do_while";
        protected static String LOOP_UNIT = "loop_unit";
    }
}