using System;

namespace com.xross.tools.xunit
{
    public interface Locator : Unit
    {
        String locate(Context ctx);
        void setDefaultKey(String key);
        String getDefaultKey();
    }
}