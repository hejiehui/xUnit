namespace com.xross.tools.xunit
{
    public interface Adapter : Unit
    {
        void setUnit(Unit unit);
    }
}