using com.xross.tools.xunit.def;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Reflection;
using System.Xml;

namespace com.xross.tools.xunit
{
    public class XunitFactory : XunitConstants
    {
        public static XunitFactory load(Uri url)
        {
            try
            {
                WebRequest request = WebRequest.Create(url);
                Stream stream = null;
                using (WebResponse response = request.GetResponse())
                {
                    stream = response.GetResponseStream();
                }

                return load(stream);
            }
            catch (Exception)
            {
                throw;
            }
        }

        /**
         * It will first check model file from file path, if it does not exist, it will try classpath then. 
         * @param path
         * @return
         * @throws Exception
         */
        public static XunitFactory load(String path)
        {
            try
            {
                Stream input;

                if (File.Exists(path))
                    input = new FileStream(path, FileMode.Open, FileAccess.Read);
                else
                {
                    Assembly classLoader = Assembly.GetExecutingAssembly();

                    if (classLoader == null)
                        classLoader = typeof(XunitFactory).Assembly;

                    String directory = Path.GetDirectoryName(classLoader.Location);
                    String filePath = Path.Combine(directory, path);
                    input = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                }

                return load(input);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static XunitFactory load(Stream input)
        {
            XunitFactory factory = null;
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(input);
                factory = getFromDocument(doc);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                try
                {
                    if (input != null)
                        input.Close();
                }
                catch (Exception)
                {
                }
            }
            return factory;
        }

        private static ICollection<String> WRAPPED_UNITS = new HashSet<String>();
        static XunitFactory()
        {
            WRAPPED_UNITS.Add(DECORATOR_UNIT);
            WRAPPED_UNITS.Add(ADAPTER_UNIT);
            WRAPPED_UNITS.Add(VALID_UNIT);
            WRAPPED_UNITS.Add(INVALID_UNIT);
            WRAPPED_UNITS.Add(LOOP_UNIT);
            WRAPPED_UNITS.Add(BRANCH_UNIT);
        }

        private String packageId;
        private String name;
        private UnitDefRepo defRepo;

        public String getPackageId()
        {
            return packageId;
        }

        public String getName()
        {
            return name;
        }

        public Unit getUnit(String id)
        {
            try
            {
                return defRepo.getUnit(id);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Processor getProcessor(String id)
        {
            try
            {
                return (Processor)getUnit(id);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Converter getConverter(String id)
        {
            try
            {
                return (Converter)getUnit(id);
            }
            catch (Exception)
            {
                throw;
            }
        }

        private static XunitFactory getFromDocument(XmlDocument doc)
        {
            XunitFactory factory = new XunitFactory();
            XmlElement root = doc.DocumentElement;
            factory.packageId = root.GetAttribute(PACKAGE_ID);
            factory.name = root.GetAttribute(NAME);
            factory.defRepo = new UnitDefRepo(factory.createApplicationProperties(doc));
            factory.readUnits(doc);

            return factory;
        }

        private IDictionary<String, String> createApplicationProperties(XmlDocument doc)
        {
            if (doc.GetElementsByTagName(PROPERTIES).Count == 0)
                return new Dictionary<String, String>();    //Collections.emptyMap();

            return getProperties(doc.GetElementsByTagName(PROPERTIES).Item(0));
        }

        private void readUnits(XmlDocument doc)
        {
            XmlNodeList unitNodes = doc.GetElementsByTagName(UNITS).Item(0).ChildNodes;

            for (int i = 0; i < unitNodes.Count; i++)
            {
                String key = getAttribute(unitNodes.Item(i), NAME);
                UnitDef unitDef = createUnitNode(unitNodes.Item(i));
                defRepo.put(key, unitDef);
            }
        }

        private UnitDef createUnitNode(XmlNode node)
        {
            if (node == null)
                return null;

            UnitDef unitDef = createPrimaryUnit(node);
            if (unitDef != null)
                return unitDef;

            if (WRAPPED_UNITS.Contains(node.Name))
                unitDef = createUnitNode(node.ChildNodes.Item(0));

            return unitDef;
        }

        private UnitDef createPrimaryUnit(XmlNode node)
        {
            String nodeName = node.Name;
            UnitDef unitDef = null;

            if (PROCESSOR.Equals(nodeName))
                unitDef = createProcessorNode(node);
            if (CONVERTER.Equals(nodeName))
                unitDef = createConverterNode(node);
            if (DECORATOR.Equals(nodeName))
                unitDef = createDecoratorNode(node);
            if (ADAPTER.Equals(nodeName))
                unitDef = createAdapterNode(node);
            else if (VALIDATOR.Equals(nodeName))
                unitDef = createValidatorNode(node);
            else if (LOCATOR.Equals(nodeName))
                unitDef = createLocatorNode(node);
            else if (CHAIN.Equals(nodeName))
                unitDef = createChainNode(node);
            else if (BI_BRANCH.Equals(nodeName))
                unitDef = createBiBranchNode(node);
            else if (BRANCH.Equals(nodeName))
                unitDef = createBranchNode(node);
            else if (WHILE.Equals(nodeName))
                unitDef = createPreValidationLoopNode(node);
            else if (DO_WHILE.Equals(nodeName))
                unitDef = createPostValidationLoopNode(node);

            if (unitDef == null)
                return null;

            unitDef.setUnitDefRepo(defRepo);
            unitDef.setName(getAttribute(node, NAME));
            unitDef.setDescription(getAttribute(node, DESCRIPTION));
            unitDef.setClassName(getAttribute(node, CLASS));
            unitDef.setReferenceName(getAttribute(node, REFERENCE));
            unitDef.setType(getType(node));
            unitDef.setProperties(getProperties(node));

            return unitDef;
        }

        private Dictionary<String, String> getProperties(XmlNode node)
        {
            XmlNodeList children = node.ChildNodes;
            XmlNode entryNode;
            Dictionary<String, String> properties = new Dictionary<String, String>();

            for (int i = 0; i < children.Count; i++)
            {
                if (!children.Item(i).Name.Equals(PROPERTY, StringComparison.OrdinalIgnoreCase))
                    continue;
                entryNode = children.Item(i);

                String key = getAttribute(entryNode, KEY);
                if (!properties.ContainsKey(key))
                    properties.Add(key, null);
                properties[key] = getAttribute(entryNode, VALUE);
            }

            return properties;
        }

        private Behavior.BehaviorType getType(XmlNode node)
        {
            String nodeName = node.Name;
            if (PROCESSOR.Equals(nodeName))
                return Behavior.BehaviorType.processor;
            if (CONVERTER.Equals(nodeName))
                return Behavior.BehaviorType.converter;
            if (LOCATOR.Equals(nodeName))
                return Behavior.BehaviorType.locator;
            if (VALIDATOR.Equals(nodeName))
                return Behavior.BehaviorType.validator;

            return (Behavior.BehaviorType)Enum.Parse(typeof(Behavior.BehaviorType), getAttribute(node, TYPE));
        }

        private UnitDef createChildNode(XmlNode node, String name)
        {
            XmlNodeList children = node.ChildNodes;
            XmlNode found = null;
            for (int i = 0; i < children.Count; i++)
            {
                if (!children.Item(i).Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                    continue;
                found = children.Item(i);
                break;
            }
            return createUnitNode(found);
        }

        private UnitDef createProcessorNode(XmlNode node)
        {
            UnitDef unitDef = new UnitDef();

            return unitDef;
        }

        private UnitDef createConverterNode(XmlNode node)
        {
            UnitDef unitDef = new UnitDef();

            return unitDef;
        }

        private UnitDef createDecoratorNode(XmlNode node)
        {
            DecoratorDef decoratorDef = new DecoratorDef();

            //		unitDef.setType(UnitType.valueOf(getAttribute(node, TYPE)));
            decoratorDef.setClassName(getAttribute(node, CLASS));
            decoratorDef.setReferenceName(getAttribute(node, REFERENCE));
            decoratorDef.setUnitDef(createChildNode(node, DECORATOR_UNIT));

            return decoratorDef;
        }

        private UnitDef createAdapterNode(XmlNode node)
        {
            AdapterDef adapterDef = new AdapterDef();

            adapterDef.setType((Behavior.BehaviorType)Enum.Parse(typeof(Behavior.BehaviorType), getAttribute(node, TYPE)));
            adapterDef.setClassName(getAttribute(node, CLASS));
            adapterDef.setReferenceName(getAttribute(node, REFERENCE));
            adapterDef.setUnitDef(createChildNode(node, ADAPTER_UNIT));

            return adapterDef;
        }

        private UnitDef createValidatorNode(XmlNode node)
        {
            ValidatorDef unitDef = new ValidatorDef();
            unitDef.setValidLabel(getAttribute(node, VALID_LABEL));
            unitDef.setInvalidLabel(getAttribute(node, VALID_LABEL));
            return unitDef;
        }

        private UnitDef createLocatorNode(XmlNode node)
        {
            LocatorDef locatorDef = new LocatorDef();
            locatorDef.setDefaultKey(getAttribute(node, DEFAULT_KEY));
            return locatorDef;
        }

        private UnitDef createChainNode(XmlNode node)
        {
            ChainDef chainDef = new ChainDef();

            XmlNodeList children = node.ChildNodes;
            for (int i = 0; i < children.Count; i++)
            {
                chainDef.addUnitDef(createUnitNode(children.Item(i)));
            }

            return chainDef;
        }

        private UnitDef createBiBranchNode(XmlNode node)
        {
            BiBranchDef biBranchDef = new BiBranchDef();

            biBranchDef.setValidatorDef((ValidatorDef)createChildNode(node, VALIDATOR));
            biBranchDef.setValidUnitDef(createChildNode(node, VALID_UNIT));
            biBranchDef.setInvalidUnitDef(createChildNode(node, INVALID_UNIT));

            return biBranchDef;
        }

        private UnitDef createBranchNode(XmlNode node)
        {
            BranchDef branchDef = new BranchDef();
            branchDef.setLocatorDef(createChildNode(node, LOCATOR));

            XmlNodeList children = node.ChildNodes;
            for (int i = 0; i < children.Count; i++)
            {
                if (!children.Item(i).Name.Equals(BRANCH_UNIT, StringComparison.OrdinalIgnoreCase))
                    continue;

                XmlNode found = children.Item(i);
                UnitDef branchUnit = createUnitNode(found);
                String key = getAttribute(found, KEY);
                branchUnit.setKey(key);
                branchDef.addBranchUnitDef(branchUnit);
            }

            return branchDef;
        }

        private UnitDef createPreValidationLoopNode(XmlNode node)
        {
            LoopDef whileLoop = new LoopDef(true);
            whileLoop.setValidatorDef((ValidatorDef)createChildNode(node, VALIDATOR));
            whileLoop.setUnitDef(createChildNode(node, LOOP_UNIT));
            return whileLoop;
        }

        private UnitDef createPostValidationLoopNode(XmlNode node)
        {
            LoopDef doWhileLoop = new LoopDef(false);
            doWhileLoop.setValidatorDef((ValidatorDef)createChildNode(node, VALIDATOR));
            doWhileLoop.setUnitDef(createChildNode(node, LOOP_UNIT));
            return doWhileLoop;
        }

        private String getAttribute(XmlNode node, String attributeName)
        {
            XmlNamedNodeMap map = node.Attributes;
            for (int i = 0; i < map.Count; i++)
                if (attributeName.Equals(map.Item(i).Name))
                    return map.Item(i).Value;

            return null;
        }
    }
}