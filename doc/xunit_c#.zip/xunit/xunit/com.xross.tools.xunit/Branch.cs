using System;

namespace com.xross.tools.xunit
{
    public interface Branch : Unit
    {
        void setLocator(Locator locator);
        void add(String key, Unit unit);
    }
}