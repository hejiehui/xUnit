namespace com.xross.tools.xunit
{
    public interface PostValidationLoop : BaseValidationLoop { }
}