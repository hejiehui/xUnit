namespace com.xross.tools.xunit
{
    public interface BiBranch : Unit
    {
        void setValidator(Validator validator);
        void setValidUnit(Unit unit);
        void setInvalidUnit(Unit unit);
    }
}