﻿using com.xross.tools.xunit;
using System;

namespace xunit.test
{
    class Program
    {
        static void Main(string[] args)
        {
            var result = XunitFactory.load(@"new_xross_unit.xunit");
            var p = result.getProcessor("a chain");
            p.process(new NewContext());
            Console.Read();
        }
    }

    class NewContext : Context { }
}
