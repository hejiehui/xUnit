﻿using com.xross.tools.xunit;
using System;

namespace xunit.test
{
    public class Demo1 : Processor
    {
        public void process(Context ctx)
        {
            Console.WriteLine("I'm demo1.");
        }
    }

    public class Demo2 : Processor
    {
        public void process(Context ctx)
        {
            Console.WriteLine("I'm demo2.");
        }
    }

    public class Demo3 : Processor
    {
        public void process(Context ctx)
        {
            Console.WriteLine("I'm demo3.");
        }
    }
}
